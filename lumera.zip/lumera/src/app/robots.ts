import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const base = process.env.APP_URL ?? 'http://localhost:3000';
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/api/', '/*/search', '/*/dashboard', '/*/account', '/*/login', '/*/register', '/*/verify', '/*/reset-password', '/*/forgot-password', '/*/admin', '/*/studio-admin', '/*/design-system'] }],
    sitemap: `${base}/sitemap.xml`,
  };
}
